-- Databricks notebook source
create catalog if not exists fdev

-- COMMAND ----------

use catalog fdev

-- COMMAND ----------

create schema if not exists bronze 
managed location 'abfss://bronze@pro2026.dfs.core.windows.net/bronze'

-- COMMAND ----------

create schema if not exists silver
managed location 'abfss://bronze@pro2026.dfs.core.windows.net/silver'

-- COMMAND ----------

create schema if not exists gold 
managed location 'abfss://bronze@pro2026.dfs.core.windows.net/gold'

-- COMMAND ----------

SHOW SCHEMAS

-- COMMAND ----------

