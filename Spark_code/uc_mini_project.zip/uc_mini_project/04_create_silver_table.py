# Databricks notebook source
# MAGIC %sql
# MAGIC select * from fdev.bronze.drivers limit 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC select driverId as did, 
# MAGIC       driverRef As dref
# MAGIC       number ,
# MAGIC       code, 
# MAGIC       concat(name.forename,' ',name.surname) as fullname,
# MAGIC       dob, 
# MAGIC       nationality,
# MAGIC       raceId, current_timestamp as ingesttime
# MAGIC  from fdev.bronze.drivers

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists fdev.silver.drivers;
# MAGIC create table if not exists fdev.silver.drivers  as
# MAGIC select driverId as did, 
# MAGIC       driverRef As dref,
# MAGIC       number ,
# MAGIC       code, 
# MAGIC       concat(name.forename,' ',name.surname) as fullname,
# MAGIC       dob, 
# MAGIC       nationality,
# MAGIC       current_timestamp as ingesttime
# MAGIC  from fdev.bronze.drivers

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists fdev.silver.results;
# MAGIC create table if not exists fdev.silver.results  as
# MAGIC select resultId as rid,
# MAGIC       raceId as race_id,
# MAGIC       driverId as did,
# MAGIC       constructorId as cid,
# MAGIC       number ,
# MAGIC       position,
# MAGIC       positionText,
# MAGIC       positionOrder,
# MAGIC       points,
# MAGIC       laps,
# MAGIC       time,
# MAGIC       milliseconds,
# MAGIC       fastestLap,
# MAGIC       rank,
# MAGIC       fastestLapTime,
# MAGIC       fastestLapSpeed,
# MAGIC       statusId,
# MAGIC       current_timestamp as ingesttime
# MAGIC  from fdev.bronze.results;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from fdev.silver.results

# COMMAND ----------

