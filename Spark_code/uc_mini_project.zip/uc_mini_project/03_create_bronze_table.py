# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC drop table if exists fdev.bronze.drivers;
# MAGIC
# MAGIC create table if not exists fdev.bronze.drivers
# MAGIC (
# MAGIC   driverId int,
# MAGIC   driverRef string,
# MAGIC   number string,
# MAGIC   code string,
# MAGIC   name struct <forename: string, surname: string>,
# MAGIC   dob  date,
# MAGIC   nationality string,
# MAGIC   url string
# MAGIC )
# MAGIC using json
# MAGIC options(path ='abfss://bronze@pro2026.dfs.core.windows.net/bronze/drivers.json')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from fdev.bronze.drivers;

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if  exists fdev.bronze.results;
# MAGIC
# MAGIC create table if not exists fdev.bronze.results
# MAGIC (
# MAGIC   resultId int,
# MAGIC   raceId int,
# MAGIC   driverId int,
# MAGIC   constructorId int,
# MAGIC   number int,
# MAGIC   position int,
# MAGIC   positionText string,
# MAGIC   positionOrder int,
# MAGIC   points double,
# MAGIC   laps int,
# MAGIC   time string,
# MAGIC   milliseconds int,
# MAGIC   fastestLap int,
# MAGIC   rank int,
# MAGIC   fastestLapTime string,
# MAGIC   fastestLapSpeed double,
# MAGIC   statusId string
# MAGIC )
# MAGIC using json
# MAGIC options(path ='abfss://bronze@pro2026.dfs.core.windows.net/bronze/results.json')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from fdev.bronze.results

# COMMAND ----------

