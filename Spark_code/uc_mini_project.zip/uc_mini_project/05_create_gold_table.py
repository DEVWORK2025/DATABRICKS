# Databricks notebook source
# MAGIC %sql
# MAGIC select  fullname, count(*) as wins
# MAGIC from fdev.silver.drivers d join fdev.silver.results r on d.did = r.did
# MAGIC where position = 1
# MAGIC group by fullname;

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists fdev.gold.driver_win;
# MAGIC
# MAGIC create table if not exists fdev.gold.driver_win as
# MAGIC select  fullname, count(*) as wins
# MAGIC from fdev.silver.drivers d join fdev.silver.results r on d.did = r.did
# MAGIC where position = 1
# MAGIC group by fullname;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from fdev.gold.driver_win order by wins

# COMMAND ----------

