-- Databricks notebook source
create external location if not exists ext_loc
URL 'abfss://bronze@pro2026.dfs.core.windows.net/bronze'
with (storage credential pro_2026_credential)

-- COMMAND ----------

desc external location ext_loc

-- COMMAND ----------

